package bidang2d;


public interface Bidang2d {
    final double r=0;
    final double panjang =0;
    final double lebar =0;
    final double tinggi =0;
    final double keliling=0;
//    final double luas =0;
    
    double hitungLuas();

    double hitungKeliling();

    
}
