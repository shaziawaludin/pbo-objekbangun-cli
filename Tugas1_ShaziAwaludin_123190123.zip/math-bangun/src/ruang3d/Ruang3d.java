package ruang3d;

public interface Ruang3d {
    
}
